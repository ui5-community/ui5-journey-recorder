jQuery.sap.declare("extend.showextensionshowcase.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("extend.showextensionshowcase.Component", {
	metadata: {
		"manifest": "json"
	}
});