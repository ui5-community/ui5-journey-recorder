sap.ui.controller("extend.showextensionshowcase.ext.controller.ListReportExt", {
	comboChange: function (oEvent) {
		var oSmartTable = this.getView().byId('extend.showextensionshowcase::sap.suite.ui.generic.template.ListReport.view.ListReport::ZSFH_C_SalesOrderHeader--listReport');
		oSmartTable.attachBeforeRebindTable(this.onBeforeRebindTable2, this);
		oSmartTable.rebindTable();
		//oSmartTable.showOverlay();
	},
  

	 onBeforeRebindTable2 : function(oEvent) {
		// Get bindinParams Object, which includes filters
		var oBindingParams = oEvent.getParameter("bindingParams");
		// Create the aFilters array
		var aFilters = oBindingParams.filters;
		// Create the table object
		var oSmartTable = oEvent.getSource();
		// Get the SmartFilterBarID
		var oSmartFilterBar = this.byId(oSmartTable.getSmartFilterId());
			if (oSmartFilterBar instanceof sap.ui.comp.smartfilterbar.SmartFilterBar) {
				var oCustomControl = oSmartFilterBar.getControlByKey("customFilter");
    				if (oCustomControl instanceof sap.m.Select) {
						var vCategory = oCustomControl.getSelectedKey();
				switch (vCategory) {
					case "0":
						aFilters.push(new sap.ui.model.Filter("billing_status", sap.ui.model.FilterOperator.EQ, ""));
						break;
					case "1":
						aFilters.push(new sap.ui.model.Filter("billing_status", sap.ui.model.FilterOperator.EQ, ""));
						break;
					default:
						break;
				}
    		}
		}
	},
	
	handleTicketApprove: function(oEvent) {
		sap.m.MessageToast.show("Approved item");
	},
	
	handleTicketReject: function(oEvent) {
		sap.m.MessageToast.show("Rejected item");
	}
});