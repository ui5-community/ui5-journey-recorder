jQuery.sap.declare("Extension2.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("Extension2.Component", {
	metadata: {
		"manifest": "json"
	}
});