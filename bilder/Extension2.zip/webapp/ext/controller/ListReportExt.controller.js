sap.ui.controller("Extension2.ext.controller.ListReportExt", {

	onClickActionZSFH_C_SalesOrderHeader1: function(oEvent) {
		sap.m.MessageToast.show("Called");
	},
	
	handleTicketApprove: function(oEvent) {
		sap.m.MessageToast.show("Approved item");
	},
	
	handleTicketReject: function(oEvent) {
		sap.m.MessageToast.show("Rejected item");
	}
});