ace.define("ace/snippets/abap",["require","exports","module"],function(r,e,m){"use strict";e.snippetText=undefined;e.scope="abap";});
