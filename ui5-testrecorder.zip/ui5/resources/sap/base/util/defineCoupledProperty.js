/*!
 * UI development toolkit for HTML5 (OpenUI5)
 * (c) Copyright 2009-2018 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define([],function(){"use strict";var d=function(t,T,s,S){var v=s[S];var p={configurable:true,get:function(){return v;},set:function(_){v=_;}};Object.defineProperty(t,T,p);Object.defineProperty(s,S,p);};return d;});
