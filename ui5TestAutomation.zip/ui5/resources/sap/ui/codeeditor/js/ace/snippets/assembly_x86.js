ace.define("ace/snippets/assembly_x86",["require","exports","module"],function(r,e,m){"use strict";e.snippetText=undefined;e.scope="assembly_x86";});
