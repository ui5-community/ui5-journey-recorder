ace.define("ace/snippets/c9search",["require","exports","module"],function(r,e,m){"use strict";e.snippetText=undefined;e.scope="c9search";});
