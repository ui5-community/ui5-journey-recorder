ace.define("ace/snippets/bro",["require","exports","module"],function(r,e,m){"use strict";e.snippetText=undefined;e.scope="";});
