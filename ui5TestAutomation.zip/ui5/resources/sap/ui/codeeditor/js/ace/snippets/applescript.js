ace.define("ace/snippets/applescript",["require","exports","module"],function(r,e,m){"use strict";e.snippetText=undefined;e.scope="applescript";});
