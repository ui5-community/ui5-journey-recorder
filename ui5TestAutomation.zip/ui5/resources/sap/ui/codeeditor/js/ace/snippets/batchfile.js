ace.define("ace/snippets/batchfile",["require","exports","module"],function(r,e,m){"use strict";e.snippetText=undefined;e.scope="batchfile";});
