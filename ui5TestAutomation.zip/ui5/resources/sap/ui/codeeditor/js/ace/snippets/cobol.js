ace.define("ace/snippets/cobol",["require","exports","module"],function(r,e,m){"use strict";e.snippetText=undefined;e.scope="cobol";});
