# UI5 Test Automation

This plugin allows you to record UI5 tests for Testcafe.